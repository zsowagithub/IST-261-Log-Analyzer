package loganalyzertable;

public class LogAnalyzerTable {

    public static void main(String[] args) {
        LogController cntl = new LogController();
    }
    
}
