package loganalyzertable;

public class LogController {
    private static final int STARTING_INDEX_OF_DISPLAY = 0;
    LogView logView;
        
    public LogController() {
                
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                LogView.createAndShowGUI();
            }
        });
    }
    
}

