
package loganalyzertable;

public class LogData {
    final String[] columnNames = {"host",
                                  "id",
                                  "userid",
                                  "timestamp",
                                  "request",
                                  "status",
                                  "size"};
    
    Object[][] data = {
        {"64.242.88.10", "-", "-", "[07/Mar/2004:16:05:49 -0800]", "GET /twiki/bin/edit/Main/Double_bounce_sender?topicparent=Main.ConfigurationVariables HTTP/1.1", "401", "12846"},
        {"64.242.88.10", "-", "-", "[07/Mar/2004:16:06:51 -0800]", "GET /twiki/bin/rdiff/TWiki/NewUserTemplate?rev1=1.3&rev2=1.2 HTTP/1.1", "200", "4523"},
        {"64.242.88.10", "-", "-", "[07/Mar/2004:16:10:02 -0800]", "GET /mailman/listinfo/hsdivision HTTP/1.1", "200", "6291"},
        {"64.242.88.10", "-", "-", "[07/Mar/2004:16:11:58 -0800]", "GET /twiki/bin/view/TWiki/WikiSyntax HTTP/1.1", "200", "7352"},
        {"64.242.88.10", "-", "-", "[07/Mar/2004:16:20:55 -0800]", "GET /twiki/bin/view/Main/DCCAndPostFix HTTP/1.1", "200", "5253"},
        {"64.242.88.10", "-", "-", "[07/Mar/2004:16:23:12 -0800]", "GET /twiki/bin/oops/TWiki/AppendixFileSystem?template=oopsmore&param1=1.12&param2=1.12 HTTP/1.1", "200", "11382"},
        {"64.242.88.10", "-", "-", "[07/Mar/2004:16:24:16 -0800]", "GET /twiki/bin/view/Main/PeterThoeny HTTP/1.1", "200", "4924"},
        {"64.242.88.10", "-", "-", "[07/Mar/2004:16:30:29 -0800]", "GET /twiki/bin/attach/Main/OfficeLocations HTTP/1.1", "401", "12851"},
        {"64.242.88.10", "-", "-", "[07/Mar/2004:16:31:48 -0800]", "GET /twiki/bin/view/TWiki/WebTopicEditTemplate HTTP/1.1", "200", "3732"},
        {"64.242.88.10", "-", "-", "[07/Mar/2004:16:32:50 -0800]", "GET /twiki/bin/view/Main/WebChanges HTTP/1.1", "200", "40520"},
        {"64.242.88.10", "-", "-", "[07/Mar/2004:16:33:53 -0800]", "GET /twiki/bin/edit/Main/Smtpd_etrn_restrictions?topicparent=Main.ConfigurationVariables HTTP/1.1", "401", "12851"}

    };
    
    public String[] getColumnNames(){
        return columnNames;
    }
    
    public Object[][] getData(){
        return data;
    }
}
