/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logs;

/**
 *
 * @author zacha
 */
public class ErrorLog {
    private final String date;
    private final String time;
    private final String year;
    private final String severity;
    private final String client;
    private final String message;
    
    public ErrorLog(String date, String time, String year, String severity, String client, String message) {
        this.date = date;
        this.time = time;
        this.year = year;
        this.severity = severity;
        this.client = client;
        this.message = message;
    }
    
    public String getDate(){
        return date;
    }
    
    public String getTime(){
        return time;
    }
    
    public String getYear(){
        return year;
    }
    
    public String getSeverity(){
        return severity;
    }
    
    public String getClient(){
        return client;
    }
    
    public String getMessage(){
        return message;
    }
    
    public void printLog(){
        System.out.println(date + "\n" + time + "\n" + year + "\n" + severity + "\n" + client + "\n" + message + "\n");
    }
}
