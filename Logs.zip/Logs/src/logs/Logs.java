package logs;


public class Logs {

    
    public static void main(String[] args) {
        System.out.println("Starting Controller");
        Controller1 ctrl = new Controller1();
        
    }
    
}
