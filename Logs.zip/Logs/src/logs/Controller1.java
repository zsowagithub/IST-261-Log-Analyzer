package logs;

import java.util.ArrayList;

public class Controller1 {
    View1 view1;
    MyTableModel tableModel;
    ErrorTableModel errorModel;
    boolean bool;
    
    
    public Controller1() {
        System.out.println("Start View 1");
        view1 = new View1();
        System.out.println("Make View 1 Visible");
        view1.setVisible(true);
        view1.getOpenButton().addActionListener(event -> view1.openFileChooser());
        view1.getSubmitButton().addActionListener(event -> startView2(view1.getFilename()));
        
               
    }
    
    public void startView2(String file1){
        String file = file1;
        System.out.println("StartMyTableModel");
        
        
        LogList logList = new LogList();
        //logList.addLogsToList(view1.getFilename());

        //System.out.println(fileName);
        System.out.println("Adding Logs to List");
        if (file.equals("access.log")){
            bool = false;
            logList.addLogsToList(file);
            tableModel = new MyTableModel(logList);
            View2.createAndShowGUI(tableModel);
        }
        if (file.equals("error.log")){
            bool = true;
            logList.addErrorLogsToList(file);
            errorModel = new ErrorTableModel(logList);
            View2.createAndShowGUI(errorModel);
        }
        ArrayList<Log> logs = logList.getLogList();

               
        
        
        
        for (int i = 0; i < logs.size(); i++){
            logs.get(i).printLog();
        }
        
    }
    
}

/*
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.AbstractTableModel;

public class ClickTable {

    public static void main(String[] args) {
        new ClickTable();
    }

    public ClickTable() {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                    ex.printStackTrace();
                }

                List<Click> clicks = new ArrayList<>(25);
                clicks.add(new Click(620, 1028));
                clicks.add(new Click(480, 230));
                ClickTableModel model = new ClickTableModel(clicks);
                JTable table = new JTable(model);

                JFrame frame = new JFrame("Testing");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.add(new JScrollPane(table));
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            }
        });
    }
*/