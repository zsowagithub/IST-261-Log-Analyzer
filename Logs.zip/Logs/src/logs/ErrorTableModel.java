package logs;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class ErrorTableModel extends AbstractTableModel{
    private final boolean DEBUG = false;
    LogList logData;
    String[] columnNames;
    final private ArrayList<ErrorLog> data;
    
    public ErrorTableModel (LogList logs){
        logData = logs;
        columnNames = logData.getColumnNames();
        data = logData.getErrorList();
    }
       
    
     
    
    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return data.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
        public String getValueAt(int rowIndex, int columnIndex) {
            ErrorLog log = data.get(rowIndex);
            String value = null;
            switch (columnIndex) {
                case 0:
                    value = log.getDate();
                    break;
                case 1:
                    value = log.getTime();
                    break;
                case 2:
                    value = log.getYear();
                    break; 
                case 3:
                    value = log.getSeverity();
                    break;
                case 4:
                    value = log.getClient();
                    break;
                case 5:
                    value = log.getMessage();
                    break;
                
            }
            return value;
        }          

    /*
     * JTable uses this method to determine the default renderer/
     * editor for each cell.  If we didn't implement this method,
     * then the last column would contain text ("true"/"false"),
     * rather than a check box.
     */
    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }

    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {
        if (col == 5) {
            return true;
        } else {
            return false;
        }
    }

    /*
     * Don't need to implement this method unless your table's
     * data can change.
     */

    public void setValueAt(Object value, int row, int col) {
        if (DEBUG) {
            System.out.println("Setting value at " + row + "," + col
                               + " to " + value
                               + " (an instance of "
                               + value.getClass() + ")");
        }

    //    data[row][col] = value;
        fireTableCellUpdated(row, col);

        if (DEBUG) {
            System.out.println("New value of data:");
            printDebugData();
        }
    }

    private void printDebugData() {
        int numRows = getRowCount();
        int numCols = getColumnCount();

        for (int i=0; i < numRows; i++) {
            System.out.print("    row " + i + ":");
            for (int j=0; j < numCols; j++) {
    //            System.out.print("  " + data[i][j]);
            }
            System.out.println();
        }
        System.out.println("--------------------------");
    }
}
