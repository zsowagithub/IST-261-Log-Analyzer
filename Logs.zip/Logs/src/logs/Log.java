package logs;


public class Log {
    private final String host;
    private final String id;
    private final String userid;
    private final String timestamp;
    private final String request;
    private final String status;
    private final String size;
    
    public Log(String host, String id, String userid, String timestamp, String request, String status, String size){
        this.timestamp = timestamp;
        this.host = host;
        this.id = id;
        this.userid = userid;
        this.request = request;
        this.status = status;
        this.size = size;
    }
    
    public String getHost(){
        return host;
    }
    
    public String getID(){
        return id;
    }
    
    public String getUserid(){
        return userid;
    }
    
    public String getTimestamp(){
        return timestamp;
    }
    
    public String getRequest(){
        return request;
    }
    
    public String getStatus(){
        return status;
    }
    
    public String getSize(){
        return size;
    }
    
    public void printLog(){
        System.out.println(host + "\n" + id + "\n" + userid + "\n" + timestamp + "\n" + request + "\n" + status + "\n" + size + "\n");
    }
}
