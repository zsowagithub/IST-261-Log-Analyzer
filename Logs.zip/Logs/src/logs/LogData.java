/*
package logs;

import java.util.ArrayList;


public class LogData {
    final String[] columnNames = {"host",
                                  "id",
                                  "userid",
                                  "timestamp",
                                  "request",
                                  "status",
                                  "size"};
    
    ArrayList<Log> logList = LogList.getList();
    
    public String[] getColumnNames(){
        return columnNames;
    }
    
    public ArrayList<Log> getData(){
        return logList;
    }
}
*/