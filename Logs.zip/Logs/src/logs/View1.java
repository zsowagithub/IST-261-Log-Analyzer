package logs;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class View1 extends JFrame {
 
    
    private JPanel instrumentPanel;
    private JPanel buttonPanel;
    //private JButton findButton;
    private JButton openButton;
    private JButton submitButton;
    
    JTextField file;
    JFileChooser fileChooser;
    JPanel logParserPanel;
        
    ArrayList<String> fileNames;
    ArrayList<ArrayList<String>> lines;
    ArrayList<String> fullFileNames;
    String filename;
    private int num;
    
    public View1() {
        initComponents();
        ///setFieldView();
    }

    private void initComponents() {
        /*
        setTitle("Log Finder");
        setSize(400, 150);
        setLocationRelativeTo(null);  // center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        instrumentPanel = new JPanel(new GridLayout(2, 1));
        instrumentPanel.add(new JLabel("File Name: (only works with 'access.log' right now)"));
        instrumentPanel.add(fileName);
        
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        findButton = new JButton("Find");
      
        buttonPanel.add(findButton);

        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(instrumentPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        */
        
        
        setTitle("Log Finder");
        setSize(600, 150);
        setLocationRelativeTo(null);  // center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        File temp = new File("Logs.java");
        lines = new ArrayList<>();
        fileNames = new ArrayList<>();
        fullFileNames = new ArrayList<>();
        String filePath = new File("").getAbsolutePath();
        fileChooser = new JFileChooser(filePath);
        fileChooser.setMultiSelectionEnabled(true);
        logParserPanel = new JPanel(new BorderLayout());
        buttonPanel = new JPanel(new GridLayout(1, 1));
        openButton = new JButton("Open a file");
        submitButton = new JButton("Submit");
        file = new JTextField("Please click 'Open a file' and select either 'access.log' or 'error.log'. Then click 'Submit'");
        logParserPanel.add(file, BorderLayout.CENTER);
        logParserPanel.add(openButton, BorderLayout.SOUTH);
        buttonPanel.add(submitButton);
        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(logParserPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        
    }
    
    public void openFileChooser() {
        int returnVal = fileChooser.showOpenDialog(logParserPanel);
        num = 0;
        if (returnVal == JFileChooser.APPROVE_OPTION) { //https://docs.oracle.com/javase/tutorial/uiswing/components/filechooser.html
            File[] filesIn = fileChooser.getSelectedFiles();
            file.setText("");
            for (int i = 0; i < filesIn.length; i++) {
                readInFile(filesIn[i]);
                fileNames.add(filesIn[i].toString().split("Logs")[1]);
                fullFileNames.add(filesIn[i].toString());
                num++;
                file.setText(file.getText() + ", " + filesIn[i].toString());
                File filePath = new File(file.getText());
                filename = filePath.getName();
                file.setText(filename);   
            }

        }
        ///finalProjectCntl.setData(lines);
        //finalProjectCntl.setFileNames(fileNames);
        //finalProjectCntl.setFullFileNames(fullFileNames);
        System.out.println(lines.size());
    }

    public void readInFile(File fileIn) {
        try {
            Scanner scanner = new Scanner(fileIn);
            ArrayList<String> temp = new ArrayList<>();
            while (scanner.hasNextLine()) {
                temp.add(scanner.nextLine());
            }
            lines.add(temp);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(View1.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    void openFieldViewer() {
        if (!lines.isEmpty()) {
            //finalProjectCntl.setData(lines);
            //SecondWindowUI secondWindowUI = new SecondWindowUI(finalProjectCntl);
            //secondWindowUI.setVisible(true);
        }

    }
    
    public JButton getOpenButton(){
        return openButton;
    }
    
    public JButton getSubmitButton(){
        return submitButton;
    }
    
    public String getFilename(){
        return filename;
    }

    /*
    private void nextView() {
       View2 view2 = new View2();
       System.out.println(fileName.getText());
       ctrl.startView2(fileName.getText());
       view2.setVisible(true);
       View2.createAndShowGUI();
    }
    */
    
    /*
    String getFilename(){
        System.out.println(fileName.getText());
        
        return fileName.getText();
    }
    */
    
    /*
    JButton getFindButton(){
        return findButton;
    }
    */

    /*private void setFieldView() {
        fileName.setText(ctrl.getStudent(indexOfItemToDisplay).getFirstName());
        lastNameDisplayValue.setText(ctrl.getStudent(indexOfItemToDisplay).getLastName());
        gpaDisplayValue.setText(ctrl.getStudent(indexOfItemToDisplay).getGpaString());
    }

    void refreshDisplayWithNewValues(int index) {
        // TODO
    }*/

    

}

