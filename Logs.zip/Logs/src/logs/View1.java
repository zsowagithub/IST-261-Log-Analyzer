package logs;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class View1 extends JFrame {


    private final JTextField fileName = new JTextField(15);
    
    
    private JPanel instrumentPanel;
    private JPanel buttonPanel;
    private JButton findButton;
    
    public View1() {
        initComponents();
        ///setFieldView();
    }

    private void initComponents() {
        setTitle("Log Finder");
        setSize(400, 150);
        setLocationRelativeTo(null);  // center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        instrumentPanel = new JPanel(new GridLayout(2, 1));
        instrumentPanel.add(new JLabel("File Name: (only works with 'access.log' right now)"));
        instrumentPanel.add(fileName);


        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        findButton = new JButton("Find");
      
        buttonPanel.add(findButton);

        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(instrumentPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }

    /*
    private void nextView() {
       View2 view2 = new View2();
       System.out.println(fileName.getText());
       ctrl.startView2(fileName.getText());
       view2.setVisible(true);
       View2.createAndShowGUI();
    }
    */
    
    String getFilename(){
        System.out.println(fileName.getText());
        
        return fileName.getText();
    }
    
    JButton getFindButton(){
        return findButton;
    }

    /*private void setFieldView() {
        fileName.setText(ctrl.getStudent(indexOfItemToDisplay).getFirstName());
        lastNameDisplayValue.setText(ctrl.getStudent(indexOfItemToDisplay).getLastName());
        gpaDisplayValue.setText(ctrl.getStudent(indexOfItemToDisplay).getGpaString());
    }

    void refreshDisplayWithNewValues(int index) {
        // TODO
    }*/

}

