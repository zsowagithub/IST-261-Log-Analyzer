package logs;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;


public class MyTableModel extends AbstractTableModel{

    private final boolean DEBUG = false;
    LogList logData;
    String[] columnNames;
    final private ArrayList<Log> data;
    
    public MyTableModel (LogList logs){
        logData = logs;
        columnNames = logData.getColumnNames();
        data = logData.getLogList();
    }
       
    
     
    
    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return data.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
        public String getValueAt(int rowIndex, int columnIndex) {
            Log log = data.get(rowIndex);
            String value = null;
            switch (columnIndex) {
                case 0:
                    value = log.getHost();
                    break;
                case 1:
                    value = log.getID();
                    break;
                case 2:
                    value = log.getUserid();
                    break; 
                case 3:
                    value = log.getTimestamp();
                    break;
                case 4:
                    value = log.getRequest();
                    break;
                case 5:
                    value = log.getStatus();
                    break;
                case 6:
                    value = log.getSize();
                    break;
            }
            return value;
        }          

    /*
     * JTable uses this method to determine the default renderer/
     * editor for each cell.  If we didn't implement this method,
     * then the last column would contain text ("true"/"false"),
     * rather than a check box.
     */
    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }

    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {
        if (col > 0 && col < 3) {
            return true;
        } else {
            return false;
        }
    }

    /*
     * Don't need to implement this method unless your table's
     * data can change.
     */

    public void setValueAt(Object value, int row, int col) {
        if (DEBUG) {
            System.out.println("Setting value at " + row + "," + col
                               + " to " + value
                               + " (an instance of "
                               + value.getClass() + ")");
        }

    //    data[row][col] = value;
        fireTableCellUpdated(row, col);

        if (DEBUG) {
            System.out.println("New value of data:");
            printDebugData();
        }
    }

    private void printDebugData() {
        int numRows = getRowCount();
        int numCols = getColumnCount();

        for (int i=0; i < numRows; i++) {
            System.out.print("    row " + i + ":");
            for (int j=0; j < numCols; j++) {
    //            System.out.print("  " + data[i][j]);
            }
            System.out.println();
        }
        System.out.println("--------------------------");
    }
}


/*
    public class ClickTableModel extends AbstractTableModel {

        private List<Click> clicks;

        public ClickTableModel(List<Click> clicks) {
            this.clicks = new ArrayList<>(clicks);
        }

        @Override
        public int getRowCount() {
            return clicks.size();
        }

        @Override
        public int getColumnCount() {
            return 2;
        }

        @Override
        public String getColumnName(int column) {
            String name = "??";
            switch (column) {
                case 0:
                    name = "Mouse X";
                    break;
                case 1:
                    name = "Mouse Y";
                    break;
            }
            return name;
        }

        @Override
        public Class<?> getColumnClass(int columnIndex) {
            Class type = String.class;
            switch (columnIndex) {
                case 0:
                case 1:
                    type = Integer.class;
                    break;
            }
            return type;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            Click click = clicks.get(rowIndex);
            Object value = null;
            switch (columnIndex) {
                case 0:
                    value = click.getX();
                    break;
                case 1:
                    value = click.getY();
                    break;
            }
            return value;
        }            
    }        
}
*/