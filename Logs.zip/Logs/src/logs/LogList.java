package logs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LogList {

    final String[] columnNames = {"host",
                                  "id",
                                  "userid",
                                  "timestamp",
                                  "request",
                                  "status",
                                  "size"};
    
    ArrayList<Log> logList = new ArrayList<>();
    
    /*
    public void addLogsToList(String fileName){
        try {
            Scanner input;
            input = new Scanner(new File(fileName));
            
            while(input.hasNextLine()) {
                String host = null;
                String id = null;
                String userid = null;
                String timestamp = null;
                String request = null;
                String status = null;
                String size = null;
                
                while (input.hasNext()){        
                    host = input.next();
                    id = input.next();
                    userid = input.next();
                    timestamp = input.next() + " " + input.next();
                    request = input.next() + " " + input.next() + " " + input.next();
                    status = input.next();
                    size = input.next();
                }
                
                Log newLog = new Log(host, id, userid, timestamp, request, status, size);
                
                logList.add(newLog);  
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Logs.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    */
    public ArrayList<Log> addLogsToList(String fileName) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line; //current line
            while ((line = br.readLine()) != null) { //creates log object from line and adds to List
		List<String> myList = new ArrayList<>(Arrays.asList(line.split(" ")));
                String host = myList.get(0);
                String id = myList.get(1);
                String userid = myList.get(2);
                String timestamp = myList.get(3) + " " + myList.get(4);
                String request = myList.get(5) + " " + myList.get(6) + " " + myList.get(7);
                String status = myList.get(8);
                String size = myList.get(9);
                
                Log log = new Log(host, id, userid, timestamp, request, status, size);
                logList.add(log);
                //log.printLog();
		}
	} catch (IOException e) {
	}
        System.out.println("Added Logs to List");
        return logList;
    
    }
    
    public String[] getColumnNames(){
        return columnNames;
    }
    
    public ArrayList getList(){
        return logList;
    }
}

